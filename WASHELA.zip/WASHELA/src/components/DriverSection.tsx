import React, { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  LocateFixed,
  LogOut,
  MapPin,
  Navigation,
  Package,
  PackageCheck,
  Phone,
  Truck,
  Wallet,
  XCircle,
} from 'lucide-react';
import { apiRequest, setStoredToken } from '../services/api';
import {
  formatIqd,
  type Driver,
  type Order,
  type OrderStatus,
  type UserAccount,
  type VehicleType,
} from '../types';
import { ORDER_STATUS_META, SENDER_TYPE_LABELS, VEHICLE_TYPE_LABELS } from '../utils/orderStatus';
import { GoogleMapsView } from './GoogleMapsView';

interface DriverSectionProps {
  currentUser: UserAccount | null;
  currentDriver: Driver | null;
  mapsApiKey: string;
  realtimeTick: number;
  onAuthChange: () => Promise<void>;
}

export const DriverSection: React.FC<DriverSectionProps> = ({
  currentUser,
  currentDriver,
  mapsApiKey,
  realtimeTick,
  onAuthChange,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [regName, setRegName] = useState('');
  const [regVehicle, setRegVehicle] = useState<VehicleType>('motorcycle');
  const [regPlate, setRegPlate] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  const [availableOrders, setAvailableOrders] = useState<Order[]>([]);
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);

  const isDriverAuthed = currentUser?.role === 'driver' && Boolean(currentDriver);

  const loadDriverOrders = useCallback(async () => {
    if (!isDriverAuthed) return;
    setOrdersLoading(true);
    try {
      const res = await apiRequest<{
        driver: Driver;
        available: Order[];
        mine: Order[];
      }>('/api/driver/orders');
      setAvailableOrders(res.available);
      setMyOrders(res.mine);
      if (!selectedOrderId) {
        const firstActive = res.mine.find(
          (o) => o.status !== 'delivered' && o.status !== 'cancelled'
        );
        if (firstActive) setSelectedOrderId(firstActive.id);
        else if (res.available[0]) setSelectedOrderId(res.available[0].id);
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر جلب طلبات التوصيل.');
    } finally {
      setOrdersLoading(false);
    }
  }, [isDriverAuthed, selectedOrderId]);

  useEffect(() => {
    void loadDriverOrders();
  }, [loadDriverOrders, realtimeTick]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await apiRequest<{ token: string; user: UserAccount }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ phone: phone.trim(), password }),
      });
      if (res.user.role !== 'driver') {
        setAuthError('هذا الحساب لا يملك صلاحية مندوب توصيل.');
        setAuthLoading(false);
        return;
      }
      setStoredToken(res.token);
      await onAuthChange();
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'فشل تسجيل الدخول.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await apiRequest<{ token: string }>('/api/auth/register-driver', {
        method: 'POST',
        body: JSON.stringify({
          name: regName.trim(),
          phone: phone.trim(),
          password,
          vehicleType: regVehicle,
          plateNumber: regPlate.trim(),
        }),
      });
      setStoredToken(res.token);
      await onAuthChange();
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'تعذر تسجيل حساب المندوب.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' });
    setStoredToken(null);
    await onAuthChange();
  };

  const handleAcceptOrder = async (orderId: string) => {
    setUpdatingOrderId(orderId);
    setActionError(null);
    try {
      await apiRequest(`/api/driver/orders/${orderId}/accept`, { method: 'POST' });
      setSelectedOrderId(orderId);
      await loadDriverOrders();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر قبول الطلب.');
    } finally {
      setUpdatingOrderId(null);
    }
  };

  const handleRejectOrder = async (orderId: string) => {
    setUpdatingOrderId(orderId);
    setActionError(null);
    try {
      await apiRequest(`/api/driver/orders/${orderId}/reject`, { method: 'POST' });
      if (selectedOrderId === orderId) {
        setSelectedOrderId(null);
      }
      await loadDriverOrders();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر رفض الطلب.');
    } finally {
      setUpdatingOrderId(null);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    setUpdatingOrderId(orderId);
    setActionError(null);
    try {
      await apiRequest(`/api/driver/orders/${orderId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      await onAuthChange();
      await loadDriverOrders();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر تحديث حالة الطلب.');
    } finally {
      setUpdatingOrderId(null);
    }
  };

  const handleToggleOnline = async () => {
    if (!currentDriver) return;
    try {
      await apiRequest('/api/driver/profile', {
        method: 'PATCH',
        body: JSON.stringify({ isOnline: !currentDriver.isOnline }),
      });
      await onAuthChange();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر تحديث حالة التوفر.');
    }
  };

  const handleUpdateGpsLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          await apiRequest('/api/driver/profile', {
            method: 'PATCH',
            body: JSON.stringify({
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
            }),
          });
          await onAuthChange();
        } catch {
          // ignore
        }
      },
      () => {
        setActionError('يرجى السماح بالوصول إلى الموقع لتحديث إحداثياتك.');
      }
    );
  };

  if (!isDriverAuthed) {
    return (
      <div className="max-w-lg mx-auto rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center mx-auto">
            <Truck className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-extrabold text-slate-900">تطبيق المندوبين — وصلها</h2>
          <p className="text-sm text-slate-500">
            سجّل دخولك لاستقبال طلبات التوصيل الحر، قبول أو رفض الطلبات، ومتابعة أرباحك (75%).
          </p>
        </div>

        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setAuthError(null);
            }}
            className={`min-h-[40px] rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
              authMode === 'login' ? 'bg-white text-sky-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            دخول مندوب
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('register');
              setAuthError(null);
            }}
            className={`min-h-[40px] rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
              authMode === 'register' ? 'bg-white text-sky-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            تسجيل مندوب جديد
          </button>
        </div>

        {authMode === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">رقم الهاتف</label>
              <input
                type="tel"
                required
                dir="ltr"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="07701112233"
                className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num focus:border-sky-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">كلمة المرور</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
                className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
              />
            </div>

            {authError && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-semibold text-rose-700">
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full min-h-[46px] rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 cursor-pointer disabled:opacity-50"
            >
              {authLoading ? 'جاري تسجيل الدخول...' : 'دخول إلى تطبيق المندوب'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">الاسم الكامل</label>
              <input
                type="text"
                required
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="مثال: أحمد كريم الشمري"
                className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">رقم الهاتف</label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="077XXXXXXXX"
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num focus:border-sky-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">نوع المركبة</label>
                <select
                  value={regVehicle}
                  onChange={(e) => setRegVehicle(e.target.value as VehicleType)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm bg-white focus:border-sky-500 focus:outline-none"
                >
                  <option value="motorcycle">دراجة نارية</option>
                  <option value="car">سيارة</option>
                  <option value="bicycle">دراجة هوائية</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">رقم اللوحة</label>
                <input
                  type="text"
                  value={regPlate}
                  onChange={(e) => setRegPlate(e.target.value)}
                  placeholder="بغداد 12345"
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">كلمة المرور</label>
                <input
                  type="password"
                  required
                  minLength={4}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="4 أحرف على الأقل"
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                />
              </div>
            </div>

            {authError && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-semibold text-rose-700">
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full min-h-[46px] rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 cursor-pointer disabled:opacity-50"
            >
              {authLoading ? 'جاري إنشاء الحساب...' : 'تسجيل حساب مندوب جديد'}
            </button>
          </form>
        )}
      </div>
    );
  }

  const activeAssigned = myOrders.filter(
    (o) => o.status !== 'delivered' && o.status !== 'cancelled'
  );
  const completedOrders = myOrders.filter((o) => o.status === 'delivered');
  const focusedOrder =
    [...activeAssigned, ...availableOrders, ...completedOrders].find(
      (o) => o.id === selectedOrderId
    ) ||
    activeAssigned[0] ||
    availableOrders[0] ||
    null;

  return (
    <div className="space-y-6">
      {/* Driver Top Status Bar */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <h2 className="text-lg font-extrabold text-slate-900">{currentDriver!.name}</h2>
            <span className="text-xs text-slate-500">
              {VEHICLE_TYPE_LABELS[currentDriver!.vehicleType]} · {currentDriver!.plateNumber}
            </span>
          </div>
          <p className="text-xs text-slate-500 font-mono-num">{currentDriver!.phone}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleUpdateGpsLocation}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            <LocateFixed className="w-4 h-4 text-sky-600" />
            <span>تحديث GPS</span>
          </button>

          <button
            type="button"
            onClick={handleToggleOnline}
            className={`min-h-[40px] px-4 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
              currentDriver!.isOnline
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
            }`}
          >
            {currentDriver!.isOnline ? 'متصل — يستقبل طلبات' : 'غير متصل'}
          </button>

          <button
            type="button"
            onClick={handleLogout}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 text-xs font-semibold text-rose-700 hover:bg-rose-100 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>خروج</span>
          </button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Wallet className="w-4 h-4 text-sky-600" />
            <span>صافي أرباحك (75%)</span>
          </div>
          <div className="mt-2 text-2xl font-extrabold text-sky-700 font-mono-num">
            {formatIqd(currentDriver!.earningsIqd)}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>التوصيلات المكتملة</span>
          </div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 font-mono-num">
            {currentDriver!.completedCount}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Navigation className="w-4 h-4 text-cyan-600" />
            <span>طلبات قيد التنفيذ</span>
          </div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 font-mono-num">
            {activeAssigned.length}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <PackageCheck className="w-4 h-4 text-amber-600" />
            <span>طلبات متاحة للاستلام</span>
          </div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 font-mono-num">
            {availableOrders.length}
          </div>
        </div>
      </div>

      {actionError && (
        <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs font-semibold text-rose-700">
          {actionError}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Active & Available Orders */}
        <div className="lg:col-span-6 space-y-5">
          {/* Active Assigned Deliveries */}
          <div className="rounded-2xl border border-slate-200 bg-white divide-y divide-slate-100">
            <div className="px-5 py-3.5 flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">
                توصيلاتي النشطة ({activeAssigned.length})
              </h3>
              {ordersLoading && <span className="text-xs text-slate-400">تحديث...</span>}
            </div>
            {activeAssigned.length === 0 ? (
              <div className="p-6 text-center text-sm text-slate-500">
                لا توجد طلبات نشطة بحوزتك حالياً. يمكنك قبول أحد الطلبات المتاحة أدناه.
              </div>
            ) : (
              activeAssigned.map((order) => (
                <div key={order.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <button
                        type="button"
                        onClick={() => setSelectedOrderId(order.id)}
                        className="text-right font-extrabold text-sm text-sky-700 hover:underline cursor-pointer flex items-center gap-1.5"
                      >
                        <Package className="w-4 h-4 shrink-0" />
                        <span>{order.itemName}</span>
                      </button>
                      <div className="text-xs text-slate-500 mt-0.5">
                        <span className="font-mono-num font-bold">{order.trackingCode}</span> ·{' '}
                        <span>{SENDER_TYPE_LABELS[order.senderType]}</span>
                        {order.zoneName ? ` · ${order.zoneName}` : ''}
                      </div>
                    </div>
                    <span
                      className={`text-xs font-semibold px-2.5 py-0.5 rounded-md border shrink-0 ${
                        ORDER_STATUS_META[order.status].colorClass
                      }`}
                    >
                      {ORDER_STATUS_META[order.status].label}
                    </span>
                  </div>

                  {order.itemDescription && (
                    <div className="text-xs text-slate-600 bg-slate-50 rounded-lg px-3 py-1.5 border border-slate-200">
                      الوصف: {order.itemDescription}
                    </div>
                  )}

                  <div className="text-xs text-slate-700 space-y-1.5">
                    <p>
                      <strong className="text-emerald-700">الاستلام من:</strong> {order.pickupAddress}{' '}
                      ({order.senderName}) ·{' '}
                      <a
                        href={`tel:${order.senderPhone}`}
                        className="inline-flex items-center gap-1 font-mono-num text-sky-700 underline"
                      >
                        <Phone className="w-3 h-3" />
                        {order.senderPhone}
                      </a>
                    </p>
                    <p>
                      <strong className="text-sky-700">التسليم إلى:</strong> {order.deliveryAddress}
                      {order.recipientName ? ` (${order.recipientName})` : ''} ·{' '}
                      <a
                        href={`tel:${order.recipientPhone}`}
                        className="inline-flex items-center gap-1 font-mono-num text-sky-700 underline"
                      >
                        <Phone className="w-3 h-3" />
                        {order.recipientPhone}
                      </a>
                    </p>
                    {order.notes && (
                      <p className="text-slate-500">ملاحظة: {order.notes}</p>
                    )}
                    <p className="font-bold text-emerald-700 font-mono-num pt-1">
                      ربحك الصافي: {formatIqd(order.driverNetIqd)} · أجرة التوصيل:{' '}
                      {formatIqd(order.deliveryFeeIqd)} ({order.distanceKm} كم)
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setSelectedOrderId(order.id)}
                      className="min-h-[38px] px-3 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                    >
                      عرض المسار على الخريطة
                    </button>

                    {order.status === 'accepted' && (
                      <button
                        type="button"
                        disabled={updatingOrderId === order.id}
                        onClick={() => handleUpdateOrderStatus(order.id, 'picked_up')}
                        className="min-h-[38px] px-4 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 cursor-pointer disabled:opacity-50"
                      >
                        تحديث: تم استلام الغرض
                      </button>
                    )}

                    {(order.status === 'accepted' || order.status === 'picked_up') && (
                      <button
                        type="button"
                        disabled={updatingOrderId === order.id}
                        onClick={() => handleUpdateOrderStatus(order.id, 'on_the_way')}
                        className="min-h-[38px] px-4 rounded-xl bg-sky-600 text-white text-xs font-bold hover:bg-sky-700 cursor-pointer disabled:opacity-50"
                      >
                        تحديث: في الطريق للمستلم
                      </button>
                    )}

                    <button
                      type="button"
                      disabled={updatingOrderId === order.id}
                      onClick={() => handleUpdateOrderStatus(order.id, 'delivered')}
                      className="min-h-[38px] px-4 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 cursor-pointer disabled:opacity-50"
                    >
                      تأكيد: تم التسليم بنجاح
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Available Open Requests */}
          <div className="rounded-2xl border border-slate-200 bg-white divide-y divide-slate-100">
            <div className="px-5 py-3.5 font-bold text-sm text-slate-900">
              طلبات التوصيل الحر المتاحة ({availableOrders.length})
            </div>
            {availableOrders.length === 0 ? (
              <div className="p-6 text-center text-sm text-slate-500">
                لا توجد طلبات جديدة بانتظار المندوب حالياً.
              </div>
            ) : (
              availableOrders.map((order) => (
                <div key={order.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                        <Package className="w-4 h-4 text-sky-600 shrink-0" />
                        <span>{order.itemName}</span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        <span className="font-mono-num">{order.trackingCode}</span> ·{' '}
                        {SENDER_TYPE_LABELS[order.senderType]} ({order.senderName})
                        {order.zoneName ? ` · ${order.zoneName}` : ''}
                      </div>
                    </div>
                    <div className="text-left shrink-0">
                      <div className="font-mono-num text-sm font-extrabold text-emerald-700">
                        {formatIqd(order.driverNetIqd)} ربحك
                      </div>
                      <div className="text-[11px] font-mono-num text-slate-500">
                        الأجرة: {formatIqd(order.deliveryFeeIqd)}
                      </div>
                    </div>
                  </div>

                  {order.itemDescription && (
                    <div className="text-xs text-slate-600 bg-slate-50 rounded-lg px-3 py-1.5">
                      {order.itemDescription}
                    </div>
                  )}

                  <div className="text-xs text-slate-600 space-y-1">
                    <p>
                      <strong className="text-emerald-700">الاستلام:</strong> {order.pickupAddress}
                    </p>
                    <p>
                      <strong className="text-sky-700">التسليم:</strong> {order.deliveryAddress}
                    </p>
                    <p className="font-mono-num text-slate-500">
                      المسافة: {order.distanceKm} كم · المستلم:{' '}
                      {order.recipientName || 'مستلم'} ({order.recipientPhone})
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedOrderId(order.id)}
                      className="min-h-[40px] px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      معاينة على الخريطة
                    </button>
                    <button
                      type="button"
                      disabled={updatingOrderId === order.id}
                      onClick={() => handleRejectOrder(order.id)}
                      className="min-h-[40px] px-3 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 text-xs font-bold hover:bg-rose-100 inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>رفض</span>
                    </button>
                    <button
                      type="button"
                      disabled={updatingOrderId === order.id}
                      onClick={() => handleAcceptOrder(order.id)}
                      className="flex-1 min-h-[40px] rounded-xl bg-sky-600 text-white text-xs font-bold hover:bg-sky-700 cursor-pointer disabled:opacity-50"
                    >
                      {updatingOrderId === order.id ? 'جاري التنفيذ...' : 'قبول الطلب'}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Google Maps Route & Completed Deliveries History */}
        <div className="lg:col-span-6 space-y-5">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-sky-600" />
                <span>خريطة الاستلام والتسليم (Google Maps)</span>
              </h3>
              {focusedOrder && (
                <span className="text-xs font-mono-num font-bold text-sky-700">
                  {focusedOrder.trackingCode}
                </span>
              )}
            </div>

            {focusedOrder ? (
              <>
                <GoogleMapsView
                  apiKey={mapsApiKey}
                  mode="route"
                  center={{ lat: focusedOrder.pickupLat, lng: focusedOrder.pickupLng }}
                  pickup={{
                    lat: focusedOrder.pickupLat,
                    lng: focusedOrder.pickupLng,
                    label: `استلام: ${focusedOrder.senderName}`,
                  }}
                  delivery={{
                    lat: focusedOrder.deliveryLat,
                    lng: focusedOrder.deliveryLng,
                    label: `تسليم: ${focusedOrder.recipientName || focusedOrder.deliveryAddress}`,
                  }}
                  driver={{
                    lat: currentDriver!.lat,
                    lng: currentDriver!.lng,
                    label: `أنت (${currentDriver!.name})`,
                  }}
                  heightClass="h-72"
                />
                <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 rounded-xl p-3 border border-slate-200">
                  <div>
                    <span className="text-slate-500 block">نقطة الاستلام</span>
                    <span className="font-bold text-slate-900">{focusedOrder.pickupAddress}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">نقطة التسليم</span>
                    <span className="font-bold text-slate-900">{focusedOrder.deliveryAddress}</span>
                  </div>
                </div>
              </>
            ) : (
              <div className="h-64 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-sm text-slate-500">
                اختر طلباً لعرض مسار الاستلام والتسليم على خرائط جوجل.
              </div>
            )}
          </div>

          {/* Completed History */}
          <div className="rounded-2xl border border-slate-200 bg-white divide-y divide-slate-100">
            <div className="px-5 py-3.5 font-bold text-sm text-slate-900">
              سجل التوصيلات المكتملة ({completedOrders.length})
            </div>
            {completedOrders.length === 0 ? (
              <div className="p-6 text-center text-sm text-slate-500">
                لم تكمل أي توصيلات بعد.
              </div>
            ) : (
              completedOrders.map((ord) => (
                <div key={ord.id} className="p-4 flex items-center justify-between gap-3 text-sm">
                  <div>
                    <div className="font-bold text-slate-900">
                      <span className="font-mono-num">{ord.trackingCode}</span> · {ord.itemName}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {ord.pickupAddress} ← {ord.deliveryAddress} ·{' '}
                      {new Date(ord.updatedAt).toLocaleString('ar-IQ')}
                    </div>
                  </div>
                  <div className="text-left shrink-0">
                    <div className="font-bold text-emerald-700 font-mono-num">
                      +{formatIqd(ord.driverNetIqd)}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono-num">
                      {ord.distanceKm} كم (أجرة {formatIqd(ord.deliveryFeeIqd)})
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
