import React from 'react';
import { motion } from 'motion/react';
import type { AppMode } from '../types';
import waselhaLogoImg from '../assets/images/waselha_logo_1794772574954.jpg';

export const WASELHA_LOGO_URL = waselhaLogoImg;

const SPLASH_LABELS: Record<AppMode, { ar: string; en: string; sub: string; bg: string }> = {
  hub: {
    ar: 'وصلها',
    en: 'WASELHA',
    sub: 'منصة التوصيل الحر السريع للمحلات والأفراد',
    bg: 'from-sky-800 via-sky-600 to-cyan-500',
  },
  customer: {
    ar: 'وصلها للزبائن والمحلات',
    en: 'WASELHA CUSTOMER',
    sub: 'أرسل أغراضك وطردك لأي مكان وتابع المندوب لحظياً',
    bg: 'from-sky-700 via-sky-600 to-cyan-500',
  },
  driver: {
    ar: 'وصلها للمندوبين',
    en: 'WASELHA DRIVER',
    sub: 'بوابة المندوبين — استلم طلبات التوصيل واحسب أرباحك فوراً',
    bg: 'from-sky-900 via-sky-700 to-cyan-600',
  },
  manager: {
    ar: 'وصلها للإدارة',
    en: 'WASELHA MANAGER',
    sub: 'مركز القيادة — المناطق، جدول الأجور، الطلبات، والعمولات',
    bg: 'from-slate-950 via-slate-900 to-sky-900',
  },
};

export const SplashScreen: React.FC<{ visible: boolean; mode?: AppMode }> = ({
  visible,
  mode = 'hub',
}) => {
  if (!visible) return null;
  const meta = SPLASH_LABELS[mode] || SPLASH_LABELS.hub;

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-b ${meta.bg} text-white p-6`}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.35 }}
        className="flex flex-col items-center text-center"
      >
        <div className="w-28 h-28 rounded-3xl bg-white p-2 shadow-2xl shadow-sky-950/25 flex items-center justify-center overflow-hidden">
          <img
            src={WASELHA_LOGO_URL}
            alt={`شعار ${meta.ar}`}
            className="w-full h-full object-contain rounded-2xl"
          />
        </div>
        <h1 className="mt-6 text-3xl sm:text-4xl font-extrabold tracking-tight">{meta.ar}</h1>
        <p
          className="mt-1.5 text-xs sm:text-sm font-bold tracking-widest text-cyan-200 uppercase"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          {meta.en}
        </p>
        <p className="mt-3 text-sm text-sky-50 font-medium max-w-xs">{meta.sub}</p>
        <div className="mt-8 w-8 h-8 rounded-full border-3 border-white/30 border-t-white animate-spin" />
      </motion.div>
    </motion.div>
  );
};
