import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  CheckCircle2,
  Clock,
  LogIn,
  LogOut,
  MapPin,
  Package,
  Phone,
  Search,
  Send,
  Store,
  Truck,
  User,
  UserPlus,
} from 'lucide-react';
import { apiRequest, setStoredToken } from '../services/api';
import {
  calculateZoneDeliveryQuote,
  formatIqd,
  haversineDistanceKm,
  matchDeliveryZone,
  type DeliveryQuote,
  type DeliveryZone,
  type Order,
  type PricingSettings,
  type SenderType,
  type UserAccount,
  type ZoneRouteRate,
} from '../types';
import { ORDER_STATUS_META, SENDER_TYPE_LABELS } from '../utils/orderStatus';
import { GoogleMapsView } from './GoogleMapsView';

interface CustomerSectionProps {
  zones: DeliveryZone[];
  routeRates: ZoneRouteRate[];
  settings: PricingSettings;
  mapsApiKey: string;
  realtimeTick: number;
  currentUser: UserAccount | null;
  onAuthChange: () => Promise<void>;
}

const CUSTOMER_ORDERS_KEY = 'waselha_customer_order_ids';
const CUSTOMER_INFO_KEY = 'waselha_customer_profile';

export const CustomerSection: React.FC<CustomerSectionProps> = ({
  zones,
  routeRates,
  settings,
  mapsApiKey,
  realtimeTick,
  currentUser,
  onAuthChange,
}) => {
  const [subTab, setSubTab] = useState<'create' | 'orders' | 'account'>('create');

  // Auth State
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authName, setAuthName] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Parcel & Sender / Recipient Form
  const [senderType, setSenderType] = useState<SenderType>('individual');
  const [senderName, setSenderName] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(CUSTOMER_INFO_KEY) || '{}');
      return saved.name || '';
    } catch {
      return '';
    }
  });
  const [senderPhone, setSenderPhone] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(CUSTOMER_INFO_KEY) || '{}');
      return saved.phone || '';
    } catch {
      return '';
    }
  });
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [orderNotes, setOrderNotes] = useState('');

  // Pickup & Delivery Map Coordinates
  const [mapActiveTarget, setMapActiveTarget] = useState<'pickup' | 'delivery'>('pickup');
  const [pickupLoc, setPickupLoc] = useState<{ lat: number; lng: number; address: string }>({
    lat: 33.3068,
    lng: 44.4285,
    address: 'بغداد - الكرادة داخل',
  });
  const [deliveryLoc, setDeliveryLoc] = useState<{ lat: number; lng: number; address: string }>({
    lat: 33.3152,
    lng: 44.3468,
    address: 'بغداد - المنصور، شارع 14 رمضان',
  });

  // Live Quote from Server (with immediate client calculation preview)
  const [serverQuote, setServerQuote] = useState<DeliveryQuote | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);

  // Order Tracking & History
  const [trackQuery, setTrackQuery] = useState(senderPhone || '');
  const [trackedOrders, setTrackedOrders] = useState<Order[]>([]);
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [selectedTrackOrderId, setSelectedTrackOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser?.role === 'customer') {
      if (!senderName) setSenderName(currentUser.name);
      if (!senderPhone) setSenderPhone(currentUser.phone);
      if (!trackQuery) setTrackQuery(currentUser.phone);
    }
  }, [currentUser, senderName, senderPhone, trackQuery]);

  const activeZones = useMemo(() => zones.filter((z) => z.isActive), [zones]);

  const pickupZoneMatch = useMemo(
    () => matchDeliveryZone(pickupLoc.lat, pickupLoc.lng, activeZones),
    [pickupLoc.lat, pickupLoc.lng, activeZones]
  );

  const deliveryZoneMatch = useMemo(
    () => matchDeliveryZone(deliveryLoc.lat, deliveryLoc.lng, activeZones),
    [deliveryLoc.lat, deliveryLoc.lng, activeZones]
  );

  const distanceKm = useMemo(
    () => haversineDistanceKm(pickupLoc.lat, pickupLoc.lng, deliveryLoc.lat, deliveryLoc.lng),
    [pickupLoc.lat, pickupLoc.lng, deliveryLoc.lat, deliveryLoc.lng]
  );

  const localQuote = useMemo(() => {
    return calculateZoneDeliveryQuote({
      distanceKm,
      pickupLat: pickupLoc.lat,
      pickupLng: pickupLoc.lng,
      deliveryLat: deliveryLoc.lat,
      deliveryLng: deliveryLoc.lng,
      zones: activeZones,
      routeRates,
      pricing: settings,
    });
  }, [
    distanceKm,
    pickupLoc.lat,
    pickupLoc.lng,
    deliveryLoc.lat,
    deliveryLoc.lng,
    activeZones,
    routeRates,
    settings,
  ]);

  // Fetch authoritative quote from server whenever coordinates or pricing rules update
  useEffect(() => {
    let cancelled = false;
    setQuoting(true);
    const timer = setTimeout(async () => {
      try {
        const res = await apiRequest<{ quote: DeliveryQuote }>('/api/orders/quote', {
          method: 'POST',
          body: JSON.stringify({
            pickupLat: pickupLoc.lat,
            pickupLng: pickupLoc.lng,
            deliveryLat: deliveryLoc.lat,
            deliveryLng: deliveryLoc.lng,
            distanceKmOverride: distanceKm,
          }),
        });
        if (!cancelled) setServerQuote(res.quote);
      } catch {
        if (!cancelled) setServerQuote(null);
      } finally {
        if (!cancelled) setQuoting(false);
      }
    }, 180);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [
    pickupLoc.lat,
    pickupLoc.lng,
    deliveryLoc.lat,
    deliveryLoc.lng,
    distanceKm,
    realtimeTick,
    settings.updatedAt,
  ]);

  const activeQuote = serverQuote || localQuote;

  const fetchTrackedOrders = useCallback(
    async (phoneOrCode?: string) => {
      setTrackingLoading(true);
      try {
        const q = (phoneOrCode ?? trackQuery).trim();
        let url = '';
        if (q.toUpperCase().startsWith('WSH-') || q.startsWith('ord_')) {
          url = `/api/orders/track?code=${encodeURIComponent(q)}`;
        } else if (q.length >= 6) {
          url = `/api/orders/track?phone=${encodeURIComponent(q)}`;
        } else {
          const savedIds = JSON.parse(localStorage.getItem(CUSTOMER_ORDERS_KEY) || '[]') as string[];
          if (savedIds.length === 0) {
            setTrackedOrders([]);
            setTrackingLoading(false);
            return;
          }
          url = `/api/orders/track?ids=${encodeURIComponent(savedIds.join(','))}`;
        }
        const res = await apiRequest<{ orders: Order[] }>(url);
        setTrackedOrders(res.orders);
        if (res.orders.length > 0 && !selectedTrackOrderId) {
          setSelectedTrackOrderId(res.orders[0].id);
        }
      } catch {
        // Keep current list on transient error
      } finally {
        setTrackingLoading(false);
      }
    },
    [trackQuery, selectedTrackOrderId]
  );

  useEffect(() => {
    if (subTab === 'orders') {
      void fetchTrackedOrders();
    }
  }, [subTab, realtimeTick, fetchTrackedOrders]);

  const handleSelectZoneForActiveTarget = (zone: DeliveryZone) => {
    const point = {
      lat: zone.centerLat,
      lng: zone.centerLng,
      address: `${zone.city} - ${zone.name}`,
    };
    if (mapActiveTarget === 'pickup') {
      setPickupLoc(point);
    } else {
      setDeliveryLoc(point);
    }
  };

  const handleSwapLocations = () => {
    const prevPickup = pickupLoc;
    setPickupLoc(deliveryLoc);
    setDeliveryLoc(prevPickup);
  };

  const handleCustomerLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await apiRequest<{ token: string; user: UserAccount }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ phone: authPhone.trim(), password: authPassword }),
      });
      if (res.user.role !== 'customer') {
        setAuthError('هذا الحساب مخصص للمندوبين أو الإدارة.');
        setAuthLoading(false);
        return;
      }
      setStoredToken(res.token);
      setSenderName(res.user.name);
      setSenderPhone(res.user.phone);
      setTrackQuery(res.user.phone);
      await onAuthChange();
      setSubTab('create');
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'فشل تسجيل الدخول.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleCustomerRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await apiRequest<{ token: string; user: UserAccount }>(
        '/api/auth/register-customer',
        {
          method: 'POST',
          body: JSON.stringify({
            name: authName.trim(),
            phone: authPhone.trim(),
            password: authPassword,
          }),
        }
      );
      setStoredToken(res.token);
      setSenderName(res.user.name);
      setSenderPhone(res.user.phone);
      setTrackQuery(res.user.phone);
      await onAuthChange();
      setSubTab('create');
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'تعذر إنشاء الحساب.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' });
    setStoredToken(null);
    await onAuthChange();
  };

  const handleCreateDeliveryOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeQuote.covered) return;

    setSubmitting(true);
    setSubmitError(null);
    try {
      const res = await apiRequest<{ order: Order }>('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          senderType,
          senderName: senderName.trim(),
          senderPhone: senderPhone.trim(),
          recipientName: recipientName.trim() || undefined,
          recipientPhone: recipientPhone.trim(),
          itemName: itemName.trim(),
          itemDescription: itemDescription.trim() || undefined,
          pickupAddress: pickupLoc.address.trim(),
          pickupLat: pickupLoc.lat,
          pickupLng: pickupLoc.lng,
          deliveryAddress: deliveryLoc.address.trim(),
          deliveryLat: deliveryLoc.lat,
          deliveryLng: deliveryLoc.lng,
          notes: orderNotes.trim() || undefined,
          distanceKmOverride: distanceKm,
        }),
      });

      localStorage.setItem(
        CUSTOMER_INFO_KEY,
        JSON.stringify({ name: senderName.trim(), phone: senderPhone.trim() })
      );
      const existingIds = JSON.parse(
        localStorage.getItem(CUSTOMER_ORDERS_KEY) || '[]'
      ) as string[];
      localStorage.setItem(
        CUSTOMER_ORDERS_KEY,
        JSON.stringify(
          [res.order.id, ...existingIds.filter((id) => id !== res.order.id)].slice(0, 25)
        )
      );

      setLastPlacedOrder(res.order);
      setTrackQuery(senderPhone.trim());
      setSelectedTrackOrderId(res.order.id);
      setItemName('');
      setItemDescription('');
      setRecipientName('');
      setRecipientPhone('');
      setOrderNotes('');
      setSubTab('orders');
      await fetchTrackedOrders(senderPhone.trim());
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'تعذر إرسال طلب التوصيل.');
    } finally {
      setSubmitting(false);
    }
  };

  const activeTrackedOrder = useMemo(
    () => trackedOrders.find((o) => o.id === selectedTrackOrderId) || trackedOrders[0] || null,
    [trackedOrders, selectedTrackOrderId]
  );

  return (
    <div className="space-y-6">
      {/* Segmented Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 rounded-xl">
          <button
            type="button"
            onClick={() => setSubTab('create')}
            className={`min-h-[40px] px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'create'
                ? 'bg-white text-sky-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            طلب توصيل جديد
          </button>
          <button
            type="button"
            onClick={() => setSubTab('orders')}
            className={`min-h-[40px] px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'orders'
                ? 'bg-white text-sky-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تتبع الطلبات والسجل
          </button>
          <button
            type="button"
            onClick={() => setSubTab('account')}
            className={`min-h-[40px] px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'account'
                ? 'bg-white text-sky-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {currentUser?.role === 'customer' ? currentUser.name : 'حسابي'}
          </button>
        </div>

        <div className="text-xs text-slate-600 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-sky-600 shrink-0" />
          <span className="font-medium">
            {activeZones.filter((z) => z.isCovered).length} مناطق مغطاة · النطاق{' '}
            <span className="font-mono-num font-bold">
              {formatIqd(settings.minFeeIqd)} – {formatIqd(settings.maxFeeIqd)}
            </span>
          </span>
        </div>
      </div>

      {/* TAB: ACCOUNT */}
      {subTab === 'account' && (
        <div className="max-w-md mx-auto rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 space-y-6">
          {currentUser?.role === 'customer' ? (
            <div className="space-y-4 text-center">
              <div className="w-14 h-14 rounded-2xl bg-sky-50 text-sky-700 flex items-center justify-center mx-auto">
                <User className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-extrabold text-slate-900">{currentUser.name}</h3>
                <p className="text-sm text-slate-500 font-mono-num mt-1">{currentUser.phone}</p>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 text-sm font-bold hover:bg-rose-100 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          ) : (
            <>
              <div className="text-center space-y-1.5">
                <h3 className="text-xl font-extrabold text-slate-900">
                  حساب الزبون أو المحل — وصلها
                </h3>
                <p className="text-xs text-slate-500">
                  سجّل دخولك لحفظ بيانات الإرسال ومتابعة جميع طلبات التوصيل من أي هاتف.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setAuthError(null);
                  }}
                  className={`min-h-[38px] rounded-lg text-xs font-bold cursor-pointer ${
                    authMode === 'login' ? 'bg-white text-sky-700 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  تسجيل الدخول
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('register');
                    setAuthError(null);
                  }}
                  className={`min-h-[38px] rounded-lg text-xs font-bold cursor-pointer ${
                    authMode === 'register' ? 'bg-white text-sky-700 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  إنشاء حساب جديد
                </button>
              </div>

              {authMode === 'login' ? (
                <form onSubmit={handleCustomerLogin} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={authPhone}
                      onChange={(e) => setAuthPhone(e.target.value)}
                      placeholder="077XXXXXXXX"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      كلمة المرور
                    </label>
                    <input
                      type="password"
                      required
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      placeholder="••••••"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm"
                    />
                  </div>
                  {authError && (
                    <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs font-semibold text-rose-700">
                      {authError}
                    </div>
                  )}
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-sky-600 text-white text-sm font-bold hover:bg-sky-700 cursor-pointer disabled:opacity-50"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>{authLoading ? 'جاري الدخول...' : 'دخول'}</span>
                  </button>
                </form>
              ) : (
                <form onSubmit={handleCustomerRegister} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      الاسم أو اسم المحل
                    </label>
                    <input
                      type="text"
                      required
                      value={authName}
                      onChange={(e) => setAuthName(e.target.value)}
                      placeholder="مثال: مصطفى الجبوري أو مطعم النخيل"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={authPhone}
                      onChange={(e) => setAuthPhone(e.target.value)}
                      placeholder="077XXXXXXXX"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      كلمة المرور
                    </label>
                    <input
                      type="password"
                      required
                      minLength={4}
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      placeholder="4 أحرف على الأقل"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm"
                    />
                  </div>
                  {authError && (
                    <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs font-semibold text-rose-700">
                      {authError}
                    </div>
                  )}
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-sky-600 text-white text-sm font-bold hover:bg-sky-700 cursor-pointer disabled:opacity-50"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>{authLoading ? 'جاري التسجيل...' : 'إنشاء الحساب'}</span>
                  </button>
                </form>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB: CREATE FREELANCE COURIER DELIVERY REQUEST */}
      {subTab === 'create' && (
        <div className="space-y-6">
          {/* Hero Banner */}
          <div className="rounded-3xl bg-gradient-to-l from-sky-700 via-sky-600 to-cyan-600 p-6 sm:p-7 text-white shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="space-y-2 max-w-2xl">
                <h2 className="text-2xl sm:text-3xl font-extrabold leading-tight">
                  أرسل أي غرض أو طرد مع أقرب مندوب وصلها
                </h2>
                <p className="text-sm text-sky-50 leading-relaxed">
                  خدمة توصيل حر للأفراد وأصحاب المحلات والمطاعم والمتاجر — حدد موقع الاستلام وموقع
                  التسليم، اكتب تفاصيل الغرض، وشاهد أجرة التوصيل فوراً قبل تأكيد الطلب.
                </p>
              </div>
              <div className="rounded-2xl bg-white/15 backdrop-blur-sm border border-white/20 px-4 py-3 text-center shrink-0">
                <div className="text-xs text-cyan-100">الأجرة المقدرة للمسار الحالي</div>
                <div className="text-2xl font-extrabold font-mono-num mt-0.5">
                  {activeQuote.covered ? formatIqd(activeQuote.deliveryFeeIqd) : 'خارج التغطية'}
                </div>
              </div>
            </div>
          </div>

          <form onSubmit={handleCreateDeliveryOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left / Map & Locations Column */}
            <div className="lg:col-span-7 space-y-5">
              {/* Step 1: Select Pickup & Delivery on Google Maps */}
              <div className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-sky-600" />
                    <span>تحديد موقع الاستلام وموقع التسليم على Google Maps</span>
                  </h3>

                  <button
                    type="button"
                    onClick={handleSwapLocations}
                    className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                  >
                    <ArrowLeftRight className="w-3.5 h-3.5 text-sky-600" />
                    <span>عكس الموقعين</span>
                  </button>
                </div>

                {/* Toggle which pin clicking on map updates */}
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl">
                  <button
                    type="button"
                    onClick={() => setMapActiveTarget('pickup')}
                    className={`min-h-[44px] rounded-xl px-3 text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      mapActiveTarget === 'pickup'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-current opacity-80" />
                    <span>تحديد موقع الاستلام (أزرق)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMapActiveTarget('delivery')}
                    className={`min-h-[44px] rounded-xl px-3 text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      mapActiveTarget === 'delivery'
                        ? 'bg-cyan-600 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-current opacity-80" />
                    <span>تحديد موقع التسليم (سماوي)</span>
                  </button>
                </div>

                {/* Quick Zone Chips for active target */}
                {activeZones.length > 0 && (
                  <div className="space-y-1.5">
                    <div className="text-[11px] font-bold text-slate-500">
                      اختيار سريع لمنطقة{' '}
                      {mapActiveTarget === 'pickup' ? 'الاستلام' : 'التسليم'} (أو انقر على الخريطة):
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto pb-1">
                      {activeZones.map((zone) => {
                        const isTargetSelected =
                          mapActiveTarget === 'pickup'
                            ? pickupZoneMatch.zone?.id === zone.id
                            : deliveryZoneMatch.zone?.id === zone.id;
                        return (
                          <button
                            key={zone.id}
                            type="button"
                            onClick={() => handleSelectZoneForActiveTarget(zone)}
                            className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                              !zone.isCovered
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : isTargetSelected
                                ? 'bg-sky-600 text-white border-sky-600'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-sky-300'
                            }`}
                          >
                            <span>{zone.name}</span>
                            <span className="font-mono-num opacity-85">
                              {!zone.isCovered
                                ? '(متوقف)'
                                : zone.pricingMode === 'fixed'
                                ? formatIqd(zone.fixedFeeIqd)
                                : `${formatIqd(zone.baseFeeIqd)}+`}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                <GoogleMapsView
                  apiKey={mapsApiKey}
                  mode="picker"
                  center={mapActiveTarget === 'pickup' ? pickupLoc : deliveryLoc}
                  pickup={{
                    lat: pickupLoc.lat,
                    lng: pickupLoc.lng,
                    label: `استلام: ${pickupLoc.address}`,
                  }}
                  delivery={{
                    lat: deliveryLoc.lat,
                    lng: deliveryLoc.lng,
                    label: `تسليم: ${deliveryLoc.address}`,
                  }}
                  zones={activeZones}
                  onLocationPicked={(lat, lng, addr) => {
                    if (mapActiveTarget === 'pickup') {
                      setPickupLoc({ lat, lng, address: addr });
                    } else {
                      setDeliveryLoc({ lat, lng, address: addr });
                    }
                  }}
                  heightClass="h-72"
                />

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      عنوان استلام الغرض{' '}
                      {pickupZoneMatch.zone && (
                        <span className="text-sky-700 font-semibold">
                          ({pickupZoneMatch.zone.name})
                        </span>
                      )}
                    </label>
                    <input
                      type="text"
                      required
                      value={pickupLoc.address}
                      onChange={(e) =>
                        setPickupLoc((prev) => ({ ...prev, address: e.target.value }))
                      }
                      onFocus={() => setMapActiveTarget('pickup')}
                      placeholder="الحي، الشارع، أقرب نقطة دالة للاستلام"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      عنوان تسليم الغرض{' '}
                      {deliveryZoneMatch.zone && (
                        <span className="text-cyan-700 font-semibold">
                          ({deliveryZoneMatch.zone.name})
                        </span>
                      )}
                    </label>
                    <input
                      type="text"
                      required
                      value={deliveryLoc.address}
                      onChange={(e) =>
                        setDeliveryLoc((prev) => ({ ...prev, address: e.target.value }))
                      }
                      onFocus={() => setMapActiveTarget('delivery')}
                      placeholder="الحي، الشارع، أقرب نقطة دالة للمستلم"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right / Parcel Details, Phones & Live Fee Quote */}
            <div className="lg:col-span-5 space-y-5">
              <div className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4">
                <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <Package className="w-5 h-5 text-sky-600" />
                  <span>تفاصيل الغرض والمرسل والمستلم</span>
                </h3>

                {/* Sender Type Selector */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSenderType('individual')}
                    className={`min-h-[40px] rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                      senderType === 'individual'
                        ? 'border-sky-600 bg-sky-50 text-sky-800'
                        : 'border-slate-200 bg-white text-slate-600'
                    }`}
                  >
                    <User className="w-4 h-4" />
                    <span>طلب شخصي (فرد)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSenderType('shop')}
                    className={`min-h-[40px] rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                      senderType === 'shop'
                        ? 'border-sky-600 bg-sky-50 text-sky-800'
                        : 'border-slate-200 bg-white text-slate-600'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>محل / مطعم / متجر</span>
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم الغرض المطلوب توصيله *
                  </label>
                  <input
                    type="text"
                    required
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    placeholder="مثال: طرد ملابس، صندوق حلويات، أوراق رسمية، جهاز..."
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    وصف الغرض أو ملاحظات للمندوب (اختياري)
                  </label>
                  <textarea
                    rows={2}
                    value={itemDescription}
                    onChange={(e) => setItemDescription(e.target.value)}
                    placeholder="حجم الغرض، قابل للكسر، موعد الاستلام أو ملاحظة..."
                    className="w-full rounded-xl border border-slate-200 p-3 text-sm focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {senderType === 'shop' ? 'اسم المحل / المرسل *' : 'اسم المرسل *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                      placeholder={senderType === 'shop' ? 'اسم المحل أو المطعم' : 'اسمك الكامل'}
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      رقم هاتف المرسل *
                    </label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={senderPhone}
                      onChange={(e) => setSenderPhone(e.target.value)}
                      placeholder="077XXXXXXXX"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      اسم المستلم (اختياري)
                    </label>
                    <input
                      type="text"
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      placeholder="اسم المستلم"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      رقم هاتف المستلم *
                    </label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={recipientPhone}
                      onChange={(e) => setRecipientPhone(e.target.value)}
                      placeholder="077XXXXXXXX"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ملاحظات إضافية (اختياري)
                  </label>
                  <input
                    type="text"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    placeholder="تعليمات إضافية للاستلام أو التسليم"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
                  />
                </div>

                {/* Live Delivery Fee Quote Box BEFORE Confirmation */}
                <div
                  className={`rounded-2xl border p-4 space-y-2 ${
                    activeQuote.covered
                      ? 'bg-sky-50/70 border-sky-200'
                      : 'bg-rose-50 border-rose-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>مسار التوصيل</span>
                    <span className="font-bold text-slate-900">
                      {activeQuote.pickupZoneName || 'نقطة استلام'} ←{' '}
                      {activeQuote.deliveryZoneName || 'نقطة تسليم'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>المسافة التقديرية</span>
                    <span className="font-mono-num font-bold text-slate-900">
                      {activeQuote.distanceKm} كم
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600 bg-white/80 rounded-xl px-3 py-1.5 border border-slate-200/70">
                    {activeQuote.breakdownLabel}
                    {quoting && ' (جاري التحديث...)'}
                  </div>

                  {activeQuote.covered ? (
                    <div className="pt-2 border-t border-sky-200/80 flex items-center justify-between">
                      <span className="text-sm font-extrabold text-slate-900">
                        أجرة التوصيل المحددة:
                      </span>
                      <span className="text-xl font-extrabold text-sky-700 font-mono-num">
                        {formatIqd(activeQuote.deliveryFeeIqd)}
                      </span>
                    </div>
                  ) : (
                    <div className="pt-2 border-t border-rose-200 flex items-start gap-2 text-xs font-bold text-rose-800">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{activeQuote.reason}</span>
                    </div>
                  )}
                </div>

                {submitError && (
                  <div className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-semibold text-rose-700">
                    {submitError}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting || !activeQuote.covered}
                  className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-2xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>
                    {submitting
                      ? 'جاري إرسال طلب التوصيل...'
                      : activeQuote.covered
                      ? `تأكيد طلب التوصيل (${formatIqd(activeQuote.deliveryFeeIqd)})`
                      : 'الموقع غير مغطى حالياً'}
                  </span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* TAB: ORDER TRACKING & HISTORY */}
      {subTab === 'orders' && (
        <div className="space-y-6">
          {lastPlacedOrder && (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                <div>
                  <h3 className="text-sm font-bold text-emerald-950">
                    تم إرسال طلب التوصيل بنجاح! رمز التتبع:{' '}
                    <span className="font-mono-num">{lastPlacedOrder.trackingCode}</span>
                  </h3>
                  <p className="text-xs text-emerald-800">
                    الغرض: {lastPlacedOrder.itemName} · الأجرة:{' '}
                    <span className="font-mono-num font-bold">
                      {formatIqd(lastPlacedOrder.deliveryFeeIqd)}
                    </span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Track Search Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void fetchTrackedOrders(trackQuery);
            }}
            className="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col sm:flex-row gap-3"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={trackQuery}
                onChange={(e) => setTrackQuery(e.target.value)}
                placeholder="أدخل رقم هاتف المرسل أو المستلم أو رمز التتبع (مثال: WSH-1003)..."
                className="w-full min-h-[44px] rounded-xl border border-slate-200 pr-10 pl-3 text-sm focus:border-sky-500 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={trackingLoading}
              className="min-h-[44px] px-6 rounded-xl bg-sky-600 text-white text-sm font-bold hover:bg-sky-700 cursor-pointer disabled:opacity-50"
            >
              {trackingLoading ? 'جاري البحث...' : 'تتبع الطلب'}
            </button>
          </form>

          {trackedOrders.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center space-y-2">
              <Package className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-800">لا توجد طلبات معروضة حالياً</h3>
              <p className="text-xs text-slate-500">
                أنشئ طلب توصيل جديد أو أدخل رقم الهاتف / رمز التتبع للبحث عن طلباتك السابقة.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Orders List */}
              <div className="lg:col-span-5 space-y-3">
                {trackedOrders.map((ord) => {
                  const statusMeta = ORDER_STATUS_META[ord.status] || ORDER_STATUS_META.pending;
                  const isSelected = activeTrackedOrder?.id === ord.id;
                  return (
                    <button
                      key={ord.id}
                      type="button"
                      onClick={() => setSelectedTrackOrderId(ord.id)}
                      className={`w-full text-right rounded-2xl border p-4 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-sky-500 bg-sky-50/40 ring-1 ring-sky-200'
                          : 'border-slate-200 bg-white hover:border-sky-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono-num font-bold text-sm text-slate-900">
                          {ord.trackingCode}
                        </span>
                        <span
                          className={`text-xs font-semibold px-2.5 py-0.5 rounded-md border ${statusMeta.colorClass}`}
                        >
                          {statusMeta.label}
                        </span>
                      </div>
                      <div className="mt-2 font-bold text-slate-900 text-sm">{ord.itemName}</div>
                      <div className="mt-1 text-xs text-slate-500 truncate">
                        {ord.pickupAddress} ← {ord.deliveryAddress}
                      </div>
                      <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
                        <span>{new Date(ord.createdAt).toLocaleString('ar-IQ')}</span>
                        <span className="font-mono-num font-bold text-sky-700">
                          {formatIqd(ord.deliveryFeeIqd)}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Live Order Tracker & Route Map */}
              {activeTrackedOrder && (
                <div className="lg:col-span-7 rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-extrabold text-slate-900 font-mono-num">
                          {activeTrackedOrder.trackingCode}
                        </span>
                        <span className="text-xs text-slate-500">
                          · {SENDER_TYPE_LABELS[activeTrackedOrder.senderType || 'individual']}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-sky-800 mt-1">
                        الغرض: {activeTrackedOrder.itemName}
                      </h4>
                      {activeTrackedOrder.itemDescription && (
                        <p className="text-xs text-slate-500 mt-0.5">
                          {activeTrackedOrder.itemDescription}
                        </p>
                      )}
                    </div>
                    <div className="text-left">
                      <div className="text-xs text-slate-500">أجرة التوصيل</div>
                      <div className="text-xl font-extrabold text-sky-700 font-mono-num">
                        {formatIqd(activeTrackedOrder.deliveryFeeIqd)}
                      </div>
                    </div>
                  </div>

                  {/* Stepper */}
                  {activeTrackedOrder.status !== 'cancelled' && (
                    <div className="grid grid-cols-5 gap-2 text-center">
                      {[
                        { label: 'بانتظار مندوب', idx: 0 },
                        { label: 'تم القبول', idx: 1 },
                        { label: 'تم الاستلام', idx: 2 },
                        { label: 'في الطريق', idx: 3 },
                        { label: 'تم التسليم', idx: 4 },
                      ].map((step) => {
                        const currentStep =
                          (ORDER_STATUS_META[activeTrackedOrder.status] || ORDER_STATUS_META.pending)
                            .stepIndex;
                        const active = currentStep >= step.idx;
                        return (
                          <div key={step.idx} className="space-y-1.5">
                            <div
                              className={`h-2 rounded-full ${
                                active ? 'bg-sky-600' : 'bg-slate-200'
                              }`}
                            />
                            <span
                              className={`text-[11px] font-semibold block ${
                                active ? 'text-sky-800' : 'text-slate-400'
                              }`}
                            >
                              {step.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Live Google Map */}
                  <GoogleMapsView
                    apiKey={mapsApiKey}
                    mode="route"
                    center={{
                      lat: activeTrackedOrder.deliveryLat,
                      lng: activeTrackedOrder.deliveryLng,
                    }}
                    pickup={{
                      lat: activeTrackedOrder.pickupLat,
                      lng: activeTrackedOrder.pickupLng,
                      label: `استلام: ${activeTrackedOrder.pickupAddress}`,
                    }}
                    delivery={{
                      lat: activeTrackedOrder.deliveryLat,
                      lng: activeTrackedOrder.deliveryLng,
                      label: `تسليم: ${activeTrackedOrder.deliveryAddress}`,
                    }}
                    heightClass="h-64"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 rounded-2xl p-4 border border-slate-200">
                    <div>
                      <span className="text-slate-500 block">من (الاستلام):</span>
                      <span className="font-bold text-slate-900">
                        {activeTrackedOrder.senderName} ·{' '}
                        <span className="font-mono-num">{activeTrackedOrder.senderPhone}</span>
                      </span>
                      <div className="text-slate-600 mt-0.5">{activeTrackedOrder.pickupAddress}</div>
                    </div>
                    <div>
                      <span className="text-slate-500 block">إلى (المستلم):</span>
                      <span className="font-bold text-slate-900">
                        {activeTrackedOrder.recipientName || 'المستلم'} ·{' '}
                        <span className="font-mono-num">{activeTrackedOrder.recipientPhone}</span>
                      </span>
                      <div className="text-slate-600 mt-0.5">
                        {activeTrackedOrder.deliveryAddress}
                      </div>
                    </div>
                  </div>

                  {activeTrackedOrder.driverName ? (
                    <div className="rounded-2xl bg-sky-50 border border-sky-200 p-3.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <Truck className="w-5 h-5 text-sky-600" />
                        <div className="text-xs">
                          <span className="text-slate-500 block">مندوب التوصيل المكلف</span>
                          <span className="font-bold text-slate-900">
                            {activeTrackedOrder.driverName}
                          </span>
                        </div>
                      </div>
                      {activeTrackedOrder.driverPhone && (
                        <a
                          href={`tel:${activeTrackedOrder.driverPhone}`}
                          className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl bg-white border border-sky-200 px-3 text-xs font-bold text-sky-700"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span className="font-mono-num">{activeTrackedOrder.driverPhone}</span>
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-600" />
                      <span>جاري إشعار أقرب المندوبين لقبول طلب التوصيل...</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
